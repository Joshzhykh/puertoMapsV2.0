package com.example.puertomaps;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity2 extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener {

    EditText txtLatitud,txtLongitud;
    GoogleMap mMap;
    Button btnAgregarEvento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txtLatitud = findViewById(R.id.txtLatitud);
        txtLongitud = findViewById(R.id.txtLongitud);
        btnAgregarEvento = findViewById(R.id.button);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager(). findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        btnAgregarEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarFormularioEvento();
            }
        });

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        this.mMap.setOnMapClickListener(this);
        this.mMap.setOnMapLongClickListener(this);
        LatLng PuertoMontt = new LatLng(-41.469993, -72.941597);
        mMap.addMarker(new MarkerOptions().position(PuertoMontt).title("La Nube"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PuertoMontt));

    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        txtLatitud.setText(""+latLng.latitude);
        txtLongitud.setText(""+latLng.longitude);

    }

    @Override
    public void onMapLongClick(@NonNull LatLng latLng) {
        txtLatitud.setText(""+latLng.latitude);
        txtLongitud.setText(""+latLng.longitude);

    }

    private void mostrarFormularioEvento() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity2.this);
        View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.bottom_sheet_form, null);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

        EditText txtEventoNombre = bottomSheetView.findViewById(R.id.txtEventoNombre);
        EditText txtEventoFecha = bottomSheetView.findViewById(R.id.txtEventoFecha);
        Button btnGuardarEvento = bottomSheetView.findViewById(R.id.btnGuardarEvento);

        btnGuardarEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes manejar el guardado del evento
                String nombreEvento = txtEventoNombre.getText().toString();
                String fechaEvento = txtEventoFecha.getText().toString();
                // Procesar datos del evento aquí

                bottomSheetDialog.dismiss(); // Cerrar el formulario
            }
        });
    }
}