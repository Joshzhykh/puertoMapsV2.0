package com.example.puertomaps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    private EditText editTextNombre, editTextEmail;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializamos las vistas
        editTextNombre = findViewById(R.id.etCorreo);
        editTextEmail = findViewById(R.id.etContraseña);
        btnLogin = findViewById(R.id.btnIniciarSesion);

        // Al hacer clic en el botón, verificamos el login
        btnLogin.setOnClickListener(v -> {
            String nombre = editTextNombre.getText().toString().trim();
            String email = editTextEmail.getText().toString().trim();


            if (nombre.isEmpty() || email.isEmpty()) {
                Toast.makeText(MainActivity.this, "Por favor ingresa todos los datos", Toast.LENGTH_SHORT).show();
            } else {
                // Verificar login
                verificarLogin(nombre, email);
            }

        });

        // Dentro de tu MainActivity o la actividad donde tienes el botón

        Button IrRegistro = findViewById(R.id.btnIrRegistrarse); // Asegúrate de que el ID coincida con el de tu botón en el XML

        IrRegistro.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, registroUsuario.class);
            startActivity(intent); // Cambia 'MainActivity' si es otra actividad desde la que navegas
        });


    }

    private void verificarLogin(String nombre, String email) {
        String url = "http://192.168.1.10/login.php";  // Cambia la IP por la de tu servidor
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    // Verificar la respuesta del servidor
                    if (response.trim().equals("Login exitoso")) {
                        Toast.makeText(MainActivity.this, "¡Bienvenido " + nombre + "!", Toast.LENGTH_SHORT).show();
                        // Iniciar la actividad de IngresarUsuario
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);
                        finish(); // Termina la actividad actual para que no pueda volver atrás al login
                    } else {
                        Toast.makeText(MainActivity.this, "Error: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    // Manejar errores
                    Toast.makeText(MainActivity.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Enviamos los datos a la API
                Map<String, String> params = new HashMap<>();
                params.put("nombre", nombre);
                params.put("email", email);
                return params;
            }
        };

        queue.add(postRequest);





    }







}
